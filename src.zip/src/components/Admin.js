// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import './Admin.css';
// import ssnLogo from './assets/ssnLogo.png';
// import ssnCampus from './assets/ssn_campus.jpeg';

// const Admin = () => {
//     const [showBanner, setShowBanner] = useState(true);
//     const [upcomingEvents, setUpcomingEvents] = useState([]);
//     const [approvedEvents, setApprovedEvents] = useState([]);
//     const [pendingEvents, setPendingEvents] = useState([]);
//     const [eventHistory, setEventHistory] = useState([]);

//     // Fetch events from Flask API
//     useEffect(() => {
//         axios.get('http://127.0.0.1:5000/events')
//             .then(response => {
//                 console.log("Fetched Events Data:", response.data);  // Debugging
//                 setUpcomingEvents(response.data.upcoming || []);
//                 setApprovedEvents(response.data.approved || []);
//                 setPendingEvents(response.data.pending || []);
//                 setEventHistory(response.data.history || []);
//             })
//             .catch(error => {
//                 console.error("Error fetching events:", error);
//             });
//     }, []);
    

//     const approveEvent = (eventId) => {
//         axios.post(`http://127.0.0.1:5000/approve/${eventId}`)
//             .then(response => {
//                 console.log("After Approving:", response.data);
//                 setUpcomingEvents(response.data.upcoming || []);
//                 setApprovedEvents(response.data.approved || []);
//                 setPendingEvents(response.data.pending || []);
//                 setEventHistory(response.data.history || []);
//             })
//             .catch(error => console.error("Error approving event:", error));
//     };
    
//     const deleteEvent = (eventId) => {
//         axios.delete(`http://127.0.0.1:5000/delete/${eventId}`)
//             .then(response => {
//                 console.log("After Deleting:", response.data);
//                 setUpcomingEvents(response.data.upcoming || []);
//                 setApprovedEvents(response.data.approved || []);
//                 setPendingEvents(response.data.pending || []);
//                 setEventHistory(response.data.history || []);
//             })
//             .catch(error => console.error("Error deleting event:", error));
//     };

//     // Event Card Component
//     const EventCard = ({ title, type, events = [] }) => (
//         <div className="event-card">
//             <h2 className="event-header">{title}</h2>
//             {events.length > 0 ? (
//                 events.map(event => (
//                     <div key={event.id} className="event-item">
//                         <p>{event.title} - {event.date}</p>
//                         {type === 'pending' && (
//                             <div className="button-group">
//                                 <button className="approve-button" onClick={() => approveEvent(event.id)}>Approve</button>
//                                 <button className="reject-button" onClick={() => deleteEvent(event.id)}>Reject</button>
//                             </div>
//                         )}
//                     </div>
//                 ))
//             ) : (
//                 <p>No events available.</p>
//             )}
//         </div>
//     );
    
//     return (
//         <div>
//             {/* Navigation Bar */}
//             <nav className="navbar">
//                 <div className="navbar-left">
//                     <img src={ssnLogo} alt="SSN College Logo" className="ssn-logo" />
//                 </div>
//                 <div className="navbar-right">
//                     <a href="#" className="nav-link">Home</a>
//                     <a href="#" className="nav-link">About SSN</a>
//                     <a href="#" className="nav-link">List of Events</a>
//                     <input type="text" placeholder="Search..." className="search-bar" />
//                     <button className="logout-button">Logout</button>
//                 </div>
//             </nav>

//             {/* Image Banner */}
//             {showBanner && (
//                 <div className="image-banner">
//                     <img src={ssnCampus} alt="SSN Campus" className="campus-image" />
//                     <div className="banner-text">ADMIN DASHBOARD</div>
//                 </div>
//             )}

//              {/* News Ticker */}
//              <div className="news-ticker">
//     <marquee behavior="scroll" direction="left" scrollamount="8" onMouseOver={(e) => e.target.stop()} onMouseOut={(e) => e.target.start()}>
//         🚀 February 28, 2025: One Day National Workshop on “Demystifying MEAN Stack Development” &nbsp;&nbsp;
//         ⏳ Hackathon registrations closing soon! &nbsp;&nbsp;
//         🔔 4 events left for approval &nbsp;&nbsp;
//         📅 Web Dev Workshop tomorrow!
//     </marquee>
// </div>


//             {/* Dashboard Content */}
//             <div className="event-container">
//                 <div className="event-row">
//                     <EventCard title="Upcoming Events" type="upcoming" events={upcomingEvents} />
//                     <EventCard title="To Be Approved" type="pending" events={pendingEvents} />
//                 </div>
//                 <div className="event-row">
//                     <EventCard title="Approved Events" type="approved" events={approvedEvents} />
//                     <EventCard title="Event History" type="history" events={eventHistory} />
//                 </div>
//             </div>
//         </div>
//     );
// };

// export default Admin;




// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import './Admin.css';
// import ssnLogo from './assets/ssnLogo.png';
// import ssnCampus from './assets/ssn_campus.jpeg';

// const Admin = () => {
//     const [activeTab, setActiveTab] = useState('upcoming');
//     const [showBanner, setShowBanner] = useState(true);
//     const [upcomingEvents, setUpcomingEvents] = useState([]);
//     const [approvedEvents, setApprovedEvents] = useState([]);
//     const [pendingEvents, setPendingEvents] = useState([]);
//     const [eventHistory, setEventHistory] = useState([]);

//     useEffect(() => {
//         axios.get('http://127.0.0.1:5000/events')
//             .then(response => {
//                 setUpcomingEvents(response.data.upcoming || []);
//                 setApprovedEvents(response.data.approved || []);
//                 setPendingEvents(response.data.pending || []);
//                 setEventHistory(response.data.history || []);
//             })
//             .catch(error => console.error("Error fetching events:", error));
//     }, []);

//     useEffect(() => {
//         document.body.style.background = "#ffffff";
//         const handleScroll = () => {
//             setShowBanner(window.scrollY <= 100);
//         };
//         window.addEventListener('scroll', handleScroll);
//         return () => window.removeEventListener('scroll', handleScroll);
//     }, []);

//     const approveEvent = (eventId) => {
//         axios.post(`http://127.0.0.1:5000/approve/${eventId}`)
//             .then(response => {
//                 setUpcomingEvents(response.data.upcoming || []);
//                 setApprovedEvents(response.data.approved || []);
//                 setPendingEvents(response.data.pending || []);
//                 setEventHistory(response.data.history || []);
//             })
//             .catch(error => console.error("Error approving event:", error));
//     };

//     const deleteEvent = (eventId) => {
//         axios.delete(`http://127.0.0.1:5000/delete/${eventId}`)
//             .then(response => {
//                 setUpcomingEvents(response.data.upcoming || []);
//                 setApprovedEvents(response.data.approved || []);
//                 setPendingEvents(response.data.pending || []);
//                 setEventHistory(response.data.history || []);
//             })
//             .catch(error => console.error("Error deleting event:", error));
//     };

//     return (
//         <div className="admin-container">
//             <nav className="navbar">
//                 <div className="navbar-left">
//                     <img src={ssnLogo} alt="SSN College Logo" className="ssn-logo" />
//                 </div>
//                 <div className="navbar-right">
//                     <a href="#" className="nav-link">Home</a>
//                     <a href="#" className="nav-link">About SSN</a>
//                     <a href="#" className="nav-link">Events</a>
//                     <input type="text" placeholder="Search..." className="search-bar" />
//                     <button className="logout-button">Logout</button>
//                 </div>
//             </nav>

//             {showBanner && (
//                 <div className="image-banner">
//                     <img src={ssnCampus} alt="SSN Campus" className="campus-image" />
//                     <div className="banner-text">ADMIN DASHBOARD</div>
//                 </div>
//             )}

//             <div className="dashboard-container">
//                 <div className="sidebar">
//                     <button className={activeTab === 'upcoming' ? 'sidebar-btn active' : 'sidebar-btn'} onClick={() => setActiveTab('upcoming')}>Upcoming Events</button>
//                     <button className={activeTab === 'pending' ? 'sidebar-btn active' : 'sidebar-btn'} onClick={() => setActiveTab('pending')}>Pending Approval</button>
//                     <button className={activeTab === 'approved' ? 'sidebar-btn active' : 'sidebar-btn'} onClick={() => setActiveTab('approved')}>Approved Events</button>
//                     <button className={activeTab === 'history' ? 'sidebar-btn active' : 'sidebar-btn'} onClick={() => setActiveTab('history')}>Event History</button>
//                 </div>

//                 <div className="main-content">
//                     {activeTab === 'upcoming' && (
//                         <div className="event-list">
//                             <h2>Upcoming Events</h2>
//                             {upcomingEvents.length > 0 ? (
//                                 upcomingEvents.map(event => (
//                                     <div key={event.id} className="event-item">
//                                         <p>{event.title} - {event.date}</p>
//                                     </div>
//                                 ))
//                             ) : <p>No upcoming events.</p>}
//                         </div>
//                     )}

//                     {activeTab === 'pending' && (
//                         <div className="event-list">
//                             <h2>Pending Approval</h2>
//                             {pendingEvents.length > 0 ? (
//                                 pendingEvents.map(event => (
//                                     <div key={event.id} className="event-item">
//                                         <p>{event.title} - {event.date}</p>
//                                         <button className="approve-button" onClick={() => approveEvent(event.id)}>Approve</button>
//                                         <button className="reject-button" onClick={() => deleteEvent(event.id)}>Reject</button>
//                                     </div>
//                                 ))
//                             ) : <p>No pending events.</p>}
//                         </div>
//                     )}

//                     {activeTab === 'approved' && (
//                         <div className="event-list">
//                             <h2>Approved Events</h2>
//                             {approvedEvents.length > 0 ? (
//                                 approvedEvents.map(event => (
//                                     <div key={event.id} className="event-item">
//                                         <p>{event.title} - {event.date}</p>
//                                     </div>
//                                 ))
//                             ) : <p>No approved events.</p>}
//                         </div>
//                     )}

//                     {activeTab === 'history' && (
//                         <div className="event-list">
//                             <h2>Event History</h2>
//                             {eventHistory.length > 0 ? (
//                                 eventHistory.map(event => (
//                                     <div key={event.id} className="event-item">
//                                         <p>{event.title} - {event.date}</p>
//                                     </div>
//                                 ))
//                             ) : <p>No past events.</p>}
//                         </div>
//                     )}
//                 </div>
//             </div>
//         </div>
//     );
// };

// export default Admin;























import React, { useState } from 'react';
import axios from 'axios';
import './Admin.css';
import ssnLogo from './assets/ssnLogo.png';
import ssnCampus from './assets/ssn_campus.jpeg';

const Admin = () => {
    const [showBanner, setShowBanner] = useState(true);
    const [activeTab, setActiveTab] = useState('upcoming');
    const [selectedEvent, setSelectedEvent] = useState(null);
    const [upcomingEvents, setUpcomingEvents] = useState([
        { id: 1, title: 'Tech Fest', date: '2025-08-15', description: 'A grand tech festival.' },
        { id: 2, title: 'AI Conference', date: '2025-09-10', description: 'Discussing AI advancements.' }
    ]);
    const [approvedEvents, setApprovedEvents] = useState([
        { id: 3, title: 'Cyber Security Talk', date: '2025-07-20', description: 'Cybersecurity awareness event.' }
    ]);
    const [pendingEvents, setPendingEvents] = useState([
        { id: 4, title: 'Hackathon', date: '2025-10-05', description: 'Competitive programming event.' }
    ]);
    const [eventHistory, setEventHistory] = useState([
        { id: 5, title: 'Web Dev Workshop', date: '2025-06-12', description: 'Learn modern web development.' }
    ]);

    const approveEvent = (eventId) => {
        const event = pendingEvents.find(event => event.id === eventId);
        setPendingEvents(pendingEvents.filter(event => event.id !== eventId));
        setApprovedEvents([...approvedEvents, event]);
        setActiveTab('approved');
    };
    
    const deleteEvent = (eventId) => {
        setPendingEvents(pendingEvents.filter(event => event.id !== eventId));
    };

    return (
        <div className="admin-dashboard-container">
            <nav className="navbar">
                <div className="navbar-left">
                    <img src={ssnLogo} alt="SSN College Logo" className="ssn-logo" />
                </div>
                <div className="navbar-right">
                    <a href="#" className="nav-link">Home</a>
                    <a href="#" className="nav-link">About SSN</a>
                    <a href="#" className="nav-link">List of Events</a>
                    <input type="text" placeholder="Search..." className="search-bar" />
                    <button className="logout-button">Logout</button>
                </div>
            </nav>

            {showBanner && (
                <div className="image-banner">
                    <img src={ssnCampus} alt="SSN Campus" className="campus-image" />
                    <div className="banner-text">ADMIN DASHBOARD</div>
                </div>
            )}

            <div className="dashboard-container">
                <div className="sidebar">
                    <button className={activeTab === 'upcoming' ? 'sidebar-btn active' : 'sidebar-btn'} onClick={() => setActiveTab('upcoming')}>Upcoming Events</button>
                    <button className={activeTab === 'pending' ? 'sidebar-btn active' : 'sidebar-btn'} onClick={() => setActiveTab('pending')}>To Be Approved</button>
                    <button className={activeTab === 'approved' ? 'sidebar-btn active' : 'sidebar-btn'} onClick={() => setActiveTab('approved')}>Approved Events</button>
                    <button className={activeTab === 'history' ? 'sidebar-btn active' : 'sidebar-btn'} onClick={() => setActiveTab('history')}>Event History</button>
                </div>

                <div className="main-content">
                    {activeTab === 'upcoming' && (
                        <div className="event-list">
                            <h2>Upcoming Events</h2>
                            {upcomingEvents.map(event => (
                                <div key={event.id} className="event-item" onClick={() => setSelectedEvent(event)}>
                                    <p>{event.title} - {event.date}</p>
                                </div>
                            ))}
                        </div>
                    )}

                    {activeTab === 'pending' && (
                        <div className="event-list">
                            <h2>To Be Approved</h2>
                            {pendingEvents.map(event => (
                                <div key={event.id} className="event-item" onClick={() => setSelectedEvent(event)}>
                                    <p>{event.title} - {event.date}</p>
                                    <button className="approve-button" onClick={() => approveEvent(event.id)}>Approve</button>
                                    <button className="reject-button" onClick={() => deleteEvent(event.id)}>Reject</button>
                                </div>
                            ))}
                        </div>
                    )}

                    {activeTab === 'approved' && (
                        <div className="event-list">
                            <h2>Approved Events</h2>
                            {approvedEvents.map(event => (
                                <div key={event.id} className="event-item" onClick={() => setSelectedEvent(event)}>
                                    <p>{event.title} - {event.date}</p>
                                </div>
                            ))}
                        </div>
                    )}

                    {activeTab === 'history' && (
                        <div className="event-list">
                            <h2>Event History</h2>
                            {eventHistory.map(event => (
                                <div key={event.id} className="event-item" onClick={() => setSelectedEvent(event)}>
                                    <p>{event.title} - {event.date}</p>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>

            {selectedEvent && (
                <div className="popup-modal">
                    <div className="modal-content">
                        <button className="close-button" onClick={() => setSelectedEvent(null)}>✖</button>
                        <h2>{selectedEvent.title}</h2>
                        <p>Date: {selectedEvent.date}</p>
                        <p>Description: {selectedEvent.description}</p>
                        <button onClick={() => setSelectedEvent(null)}>Close</button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Admin;


// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import './Admin.css';
// import ssnLogo from './assets/ssnLogo.png';
// import ssnCampus from './assets/ssn_campus.jpeg';

// const Admin = () => {
//     const [activeTab, setActiveTab] = useState('upcoming');
//     const [showBanner, setShowBanner] = useState(true);
//     const [upcomingEvents, setUpcomingEvents] = useState([]);
//     const [approvedEvents, setApprovedEvents] = useState([]);
//     const [pendingEvents, setPendingEvents] = useState([]);
//     const [eventHistory, setEventHistory] = useState([]);
//     const [selectedEvent, setSelectedEvent] = useState(null);

//     useEffect(() => {
//         axios.get('http://127.0.0.1:5000/events')
//             .then(response => {
//                 setUpcomingEvents(response.data.upcoming || []);
//                 setApprovedEvents(response.data.approved || []);
//                 setPendingEvents(response.data.pending || []);
//                 setEventHistory(response.data.history || []);
//             })
//             .catch(error => console.error("Error fetching events:", error));
//     }, []);

//     useEffect(() => {
//         document.body.style.background = "#ffffff";
//         const handleScroll = () => {
//             setShowBanner(window.scrollY <= 100);
//         };
//         window.addEventListener('scroll', handleScroll);
//         return () => window.removeEventListener('scroll', handleScroll);
//     }, []);

//     const approveEvent = (eventId) => {
//         axios.post(`http://127.0.0.1:5000/approve/${eventId}`)
//             .then(response => {
//                 setUpcomingEvents(response.data.upcoming || []);
//                 setApprovedEvents(response.data.approved || []);
//                 setPendingEvents(response.data.pending || []);
//                 setEventHistory(response.data.history || []);
//             })
//             .catch(error => console.error("Error approving event:", error));
//     };

//     const deleteEvent = (eventId) => {
//         axios.delete(`http://127.0.0.1:5000/delete/${eventId}`)
//             .then(response => {
//                 setUpcomingEvents(response.data.upcoming || []);
//                 setApprovedEvents(response.data.approved || []);
//                 setPendingEvents(response.data.pending || []);
//                 setEventHistory(response.data.history || []);
//             })
//             .catch(error => console.error("Error deleting event:", error));
//     };

//     return (
//         <div className="admin-container">
//             <nav className="navbar">
//                 <div className="navbar-left">
//                     <img src={ssnLogo} alt="SSN College Logo" className="ssn-logo" />
//                 </div>
//                 <div className="navbar-right">
//                     <a href="#" className="nav-link">Home</a>
//                     <a href="#" className="nav-link">About SSN</a>
//                     <a href="#" className="nav-link">Events</a>
//                     <input type="text" placeholder="Search..." className="search-bar" />
//                     <button className="logout-button">Logout</button>
//                 </div>
//             </nav>

//             {showBanner && (
//                 <div className="image-banner">
//                     <img src={ssnCampus} alt="SSN Campus" className="campus-image" />
//                     <div className="banner-text">ADMIN DASHBOARD</div>
//                 </div>
//             )}

//             <div className="dashboard-container">
//                 <div className="sidebar">
//                     <button className={activeTab === 'upcoming' ? 'sidebar-btn active' : 'sidebar-btn'} onClick={() => setActiveTab('upcoming')}>Upcoming Events</button>
//                     <button className={activeTab === 'pending' ? 'sidebar-btn active' : 'sidebar-btn'} onClick={() => setActiveTab('pending')}>Pending Approval</button>
//                     <button className={activeTab === 'approved' ? 'sidebar-btn active' : 'sidebar-btn'} onClick={() => setActiveTab('approved')}>Approved Events</button>
//                     <button className={activeTab === 'history' ? 'sidebar-btn active' : 'sidebar-btn'} onClick={() => setActiveTab('history')}>Event History</button>
//                 </div>

//                 <div className="main-content">
//                     {activeTab === 'upcoming' && (
//                         <div className="event-list">
//                             <h2>Upcoming Events</h2>
//                             {upcomingEvents.length > 0 ? (
//                                 upcomingEvents.map(event => (
//                                     <div key={event.id} className="event-item" onClick={() => setSelectedEvent(event)}>
//                                         <p>{event.title} - {event.date}</p>
//                                     </div>
//                                 ))
//                             ) : <p>No upcoming events.</p>}
//                         </div>
//                     )}

//                     {activeTab === 'pending' && (
//                         <div className="event-list">
//                             <h2>Pending Approval</h2>
//                             {pendingEvents.length > 0 ? (
//                                 pendingEvents.map(event => (
//                                     <div key={event.id} className="event-item" onClick={() => setSelectedEvent(event)}>
//                                         <p>{event.title} - {event.date}</p>
//                                         <button className="approve-button" onClick={() => approveEvent(event.id)}>Approve</button>
//                                         <button className="reject-button" onClick={() => deleteEvent(event.id)}>Reject</button>
//                                     </div>
//                                 ))
//                             ) : <p>No pending events.</p>}
//                         </div>
//                     )}

//                     {activeTab === 'approved' && (
//                         <div className="event-list">
//                             <h2>Approved Events</h2>
//                             {approvedEvents.length > 0 ? (
//                                 approvedEvents.map(event => (
//                                     <div key={event.id} className="event-item" onClick={() => setSelectedEvent(event)}>
//                                         <p>{event.title} - {event.date}</p>
//                                     </div>
//                                 ))
//                             ) : <p>No approved events.</p>}
//                         </div>
//                     )}

//                     {activeTab === 'history' && (
//                         <div className="event-list">
//                             <h2>Event History</h2>
//                             {eventHistory.length > 0 ? (
//                                 eventHistory.map(event => (
//                                     <div key={event.id} className="event-item" onClick={() => setSelectedEvent(event)}>
//                                         <p>{event.title} - {event.date}</p>
//                                     </div>
//                                 ))
//                             ) : <p>No past events.</p>}
//                         </div>
//                     )}
//                 </div>
//             </div>

//             {selectedEvent && (
//                 <div className="popup-modal">
//                     <div className="modal-content">
//                         <h2>{selectedEvent.title}</h2>
//                         <p>Date: {selectedEvent.date}</p>
//                         <p>Description: {selectedEvent.description}</p>
//                         <button onClick={() => setSelectedEvent(null)}>Close</button>
//                     </div>
//                 </div>
//             )}
//         </div>
//     );
// };

// export default Admin;






