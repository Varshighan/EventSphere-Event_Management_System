// import React, { useState, useEffect } from 'react';
// import './EventOrganizer.css';
// import ssnLogo from './assets/ssnLogo.png';
// import ssnCampus from './assets/ssn_campus.jpeg';

// const EventOrganizer = () => {
//     const [activeTab, setActiveTab] = useState('create');
//     const [showBanner, setShowBanner] = useState(true);
//     const [requestedEvents, setRequestedEvents] = useState([]);
//     const [approvedEvents, setApprovedEvents] = useState([]);
//     const [publishedEvents, setPublishedEvents] = useState([]);
//     const [newEvent, setNewEvent] = useState({
//         title: 'Tech Fest',
//         category: 'Conference',
//         description: 'A tech event featuring speakers and workshops',
//         eventDate: '2025-08-15T10:00',
//         venue: 'SSN Auditorium',
//         onlineLink: 'https://example.com',
//         format: 'in-person',
//         registrationLink: 'https://register.com',
//         ticketPrice: '500',
//         paymentOptions: 'Credit Card, UPI',
//         agenda: '10 AM: Keynote, 1 PM: Workshops',
//         speakers: 'John Doe, Jane Smith',
//         organizerDetails: 'Tech Club, SSN',
//         contactInfo: 'techclub@ssn.edu.in, 9876543210',
//         specialInstructions: 'Bring ID card',
//         socialLinks: 'https://twitter.com/ssn',
//         sponsors: 'ABC Corp, XYZ Pvt Ltd',
//         image: null,
//     });

//     useEffect(() => {

//         document.body.style.background = "#ffffff";

//         const handleScroll = () => {
//             setShowBanner(window.scrollY <= 100);
//         };
//         window.addEventListener('scroll', handleScroll);
//         return () => window.removeEventListener('scroll', handleScroll);
//     }, []);

//     const handleInputChange = (e) => {
//         const { name, value, type, files } = e.target;
//         if (type === 'file') {
//             setNewEvent({ ...newEvent, [name]: files[0] });
//         } else {
//             setNewEvent({ ...newEvent, [name]: value });
//         }
//     };

//     const createEvent = () => {
//         if (newEvent.title && newEvent.eventDate) {
//             const eventToRequest = { ...newEvent, id: requestedEvents.length + 1, status: 'pending' };
//             setRequestedEvents([...requestedEvents, eventToRequest]);
//             setNewEvent({
//                 title: '',
//                 category: '',
//                 description: '',
//                 eventDate: '',
//                 venue: '',
//                 onlineLink: '',
//                 format: 'in-person',
//                 registrationLink: '',
//                 ticketPrice: '',
//                 paymentOptions: '',
//                 agenda: '',
//                 speakers: '',
//                 organizerDetails: '',
//                 contactInfo: '',
//                 specialInstructions: '',
//                 socialLinks: '',
//                 sponsors: '',
//                 image: null,
//             });
//             setActiveTab('requested');
//         }
//     };

//     const publishEvent = (event) => {
//         setPublishedEvents([...publishedEvents, event]);
//         setApprovedEvents(approvedEvents.filter(e => e.id !== event.id));
//     };

//     return (
//         <div className="event-organizer-container">
//             <nav className="navbar">
//                 <div className="navbar-left">
//                     <img src={ssnLogo} alt="SSN College Logo" className="ssn-logo" />
//                 </div>
//                 <div className="navbar-right">
//                     <a href="#" className="nav-link">Home</a>
//                     <a href="#" className="nav-link">About SSN</a>
//                     <a href="#" className="nav-link">Events</a>
//                     <input type="text" placeholder="Search..." className="search-bar" />
//                     <button className="logout-button">Logout</button>
//                 </div>
//             </nav>

//             {showBanner && (
//                 <div className="image-banner">
//                     <img src={ssnCampus} alt="SSN Campus" className="campus-image" />
//                     <div className="banner-text">EVENT ORGANIZER DASHBOARD</div>
//                 </div>
//             )}

//             <div className="dashboard-container">
//                 <div className="sidebar">
//                     <button className={activeTab === 'create' ? 'sidebar-btn active' : 'sidebar-btn'} onClick={() => setActiveTab('create')}>Create Event</button>
//                     <button className={activeTab === 'requested' ? 'sidebar-btn active' : 'sidebar-btn'} onClick={() => setActiveTab('requested')}>Requested</button>
//                     <button className={activeTab === 'approved' ? 'sidebar-btn active' : 'sidebar-btn'} onClick={() => setActiveTab('approved')}>Approved</button>
//                     <button className={activeTab === 'history' ? 'sidebar-btn active' : 'sidebar-btn'} onClick={() => setActiveTab('history')}>Event History</button>
//                     <button className={activeTab === 'published' ? 'sidebar-btn active' : 'sidebar-btn'} onClick={() => setActiveTab('published')}>Published</button>
//                 </div>

//                 <div className="main-content">
//                     {activeTab === 'create' && (
//                         <div className="create-event">
//                             <h2>Create New Event</h2>
//                             <input type="text" name="title" placeholder="Event Title" value={newEvent.title} onChange={handleInputChange} />
//                             <select name="category" value={newEvent.category} onChange={handleInputChange}>
//                                 <option value="">Select Category</option>
//                                 <option value="Workshop">Workshop</option>
//                                 <option value="Seminar">Seminar</option>
//                                 <option value="Conference">Conference</option>
//                                 <option value="Cultural">Cultural</option>
//                             </select>
//                             <textarea name="description" placeholder="Event Description" value={newEvent.description} onChange={handleInputChange}></textarea>
//                             <input type="datetime-local" name="eventDate" value={newEvent.eventDate} onChange={handleInputChange} />
//                             <input type="text" name="venue" placeholder="Venue Address" value={newEvent.venue} onChange={handleInputChange} />
//                             <button className="create-button" onClick={createEvent}>Request Approval</button>
//                         </div>
//                     )}

//                     {activeTab === 'requested' && (
//                         <div className="event-requested">
//                             <h2>Requested Events</h2>
//                             {requestedEvents.map(event => (
//                                 <div key={event.id} className="event-item">
//                                     <p>{event.title} - {event.eventDate} (Status: {event.status})</p>
//                                 </div>
//                             ))}
//                         </div>
//                     )}

//                     {activeTab === 'approved' && (
//                         <div className="event-approved">
//                             <h2>Approved Events</h2>
//                             {approvedEvents.map(event => (
//                                 <div key={event.id} className="event-item">
//                                     <p>{event.title} - {event.eventDate}</p>
//                                     <button className="publish-button" onClick={() => publishEvent(event)}>Publish</button>
//                                 </div>
//                             ))}
//                         </div>
//                     )}

//                     {activeTab === 'published' && (
//                         <div className="event-published">
//                             <h2>Published Events</h2>
//                             {publishedEvents.map(event => (
//                                 <div key={event.id} className="event-item">
//                                     <p>{event.title} - {event.eventDate}</p>
//                                 </div>
//                             ))}
//                         </div>
//                     )}
//                 </div>
//             </div>
//         </div>
//     );
// };

// export default EventOrganizer;







// import React, { useState, useEffect } from 'react';
// import { db } from "./firebase"; 
// import { collection, addDoc } from "firebase/firestore";
// import { getStorage, ref, uploadBytes, getDownloadURL } from "firebase/storage";
// import './EventOrganizer.css';
// import ssnLogo from './assets/ssnLogo.png';
// import ssnCampus from './assets/ssn_campus.jpeg';


// const EventOrganizer = () => {
//     const [activeTab, setActiveTab] = useState('create');
//     const [showBanner, setShowBanner] = useState(true);
//     const [newEvent, setNewEvent] = useState({
//         title: '',
//         category: '',
//         description: '',
//         eventDate: '',
//         venue: '',
//         onlineLink: '',
//         format: 'in-person',
//         registrationLink: '',
//         ticketPrice: '',
//         paymentOptions: '',
//         agenda: '',
//         speakers: '',
//         organizerDetails: '',
//         contactInfo: '',
//         specialInstructions: '',
//         socialLinks: '',
//         sponsors: '',
//         image: null,
//     });

//     useEffect(() => {
//         document.body.style.background = "#ffffff";

//         const handleScroll = () => {
//             setShowBanner(window.scrollY <= 100);
//         };
//         window.addEventListener('scroll', handleScroll);
//         return () => window.removeEventListener('scroll', handleScroll);
//     }, []);

//     const handleInputChange = (e) => {
//         const { name, value, type, files } = e.target;
//         if (type === 'file') {
//             setNewEvent({ ...newEvent, [name]: files[0] }); // Store single file object
//         } else {
//             setNewEvent({ ...newEvent, [name]: value });
//         }
//     };

//     const createEvent = async () => {
//     if (!newEvent.title || !newEvent.eventDate) {
//         alert("Please enter a title and date for the event.");
//         return;
//     }

//     try {
//         let imageUrl = "";  // Default empty image URL

//         if (newEvent.image) {
//             const storage = getStorage();  // Initialize Firebase Storage
//             const imageRef = ref(storage, `event_images/${newEvent.image.name}`);

//             // Upload image to Firebase Storage
//             const snapshot = await uploadBytes(imageRef, newEvent.image);
//             imageUrl = await getDownloadURL(snapshot.ref); // Get the image URL
//         }

//         // Save event data in Firestore with image URL
//         const docRef = await addDoc(collection(db, "events"), {
//             ...newEvent,
//             image: imageUrl,  // Store URL instead of File object
//         });

//         alert("Event submitted successfully! Event ID: " + docRef.id);

//         // Reset form
//         setNewEvent({
//             title: '',
//             category: '',
//             description: '',
//             eventDate: '',
//             venue: '',
//             onlineLink: '',
//             format: 'in-person',
//             registrationLink: '',
//             ticketPrice: '',
//             paymentOptions: '',
//             agenda: '',
//             speakers: '',
//             organizerDetails: '',
//             contactInfo: '',
//             specialInstructions: '',
//             socialLinks: '',
//             sponsors: '',
//             image: null, // Reset image field
//         });
//     } catch (error) {
//         console.error("Error adding document: ", error);
//         alert("Error submitting event. Please try again.");
//     }
// };


//     return (
//         <div className="event-organizer-container">
//             <nav className="navbar">
//                 <div className="navbar-left">
//                     <img src={ssnLogo} alt="SSN College Logo" className="ssn-logo" />
//                 </div>
//                 <div className="navbar-right">
//                     <a href="#" className="nav-link">Home</a>
//                     <a href="#" className="nav-link">About SSN</a>
//                     <a href="#" className="nav-link">Events</a>
//                     <input type="text" placeholder="Search..." className="search-bar" />
//                     <button className="logout-button">Logout</button>
//                 </div>
//             </nav>

//             {showBanner && (
//                 <div className="image-banner">
//                     <img src={ssnCampus} alt="SSN Campus" className="campus-image" />
//                     <div className="banner-text">EVENT ORGANIZER DASHBOARD</div>
//                 </div>
//             )}

//             <div className="dashboard-container">
//                 <div className="sidebar">
//                     <button className={activeTab === 'create' ? 'sidebar-btn active' : 'sidebar-btn'} onClick={() => setActiveTab('create')}>Create Event</button>
//                 </div>

//                 <div className="main-content">
//                     {activeTab === 'create' && (
//                         <div className="create-event">
//                             <h2>Create New Event</h2>
                            
//                             <label>Event Title:</label>
//                             <input type="text" name="title" value={newEvent.title} onChange={handleInputChange} placeholder="Enter event title" />

//                             <label>Category:</label>
//                             <select name="category" value={newEvent.category} onChange={handleInputChange}>
//                                 <option value="">Select Category</option>
//                                 <option value="Workshop">Workshop</option>
//                                 <option value="Seminar">Seminar</option>
//                                 <option value="Conference">Conference</option>
//                                 <option value="Cultural">Cultural</option>
//                             </select>

//                             <label>Description:</label>
//                             <textarea name="description" value={newEvent.description} onChange={handleInputChange} placeholder="Describe your event"></textarea>

//                             <label>Date & Time:</label>
//                             <input type="datetime-local" name="eventDate" value={newEvent.eventDate} onChange={handleInputChange} />

//                             <label>Venue:</label>
//                             <input type="text" name="venue" value={newEvent.venue} onChange={handleInputChange} placeholder="Enter venue" />

//                             <label>Registration Link:</label>
//                             <input type="text" name="registrationLink" value={newEvent.registrationLink} onChange={handleInputChange} placeholder="Enter registration link" />

//                             <label>Upload Image:</label>
//                             <input type="file" name="image" onChange={handleInputChange} />

//                             <button className="create-button" onClick={createEvent}>Submit Event</button>
//                         </div>
//                     )}
//                 </div>
//             </div>
//         </div>
//     );
// };

// export default EventOrganizer;


// import React, { useState, useEffect } from 'react';
// import { db } from "./firebase"; 
// import { collection, addDoc } from "firebase/firestore";
// import { getStorage, ref, uploadBytes, getDownloadURL } from "firebase/storage";
// import './EventOrganizer.css';
// import ssnLogo from './assets/ssnLogo.png';
// import ssnCampus from './assets/ssn_campus.jpeg';

// const EventOrganizer = () => {
//     const [activeTab, setActiveTab] = useState('create');
//     const [showBanner, setShowBanner] = useState(true);
//     const [newEvent, setNewEvent] = useState({
//         title: '',
//         category: '',
//         description: '',
//         eventDate: '',
//         venue: '',
//         onlineLink: '',
//         format: 'in-person',
//         registrationLink: '',
//         ticketPrice: '',
//         paymentOptions: '',
//         agenda: '',
//         speakers: '',
//         organizerDetails: '',
//         contactInfo: '',
//         specialInstructions: '',
//         socialLinks: '',
//         sponsors: '',
//         image: null,
//     });

//     useEffect(() => {
//         document.body.style.background = "#ffffff";

//         const handleScroll = () => {
//             setShowBanner(window.scrollY <= 100);
//         };
//         window.addEventListener('scroll', handleScroll);
//         return () => window.removeEventListener('scroll', handleScroll);
//     }, []);

//     const handleInputChange = (e) => {
//         const { name, value, type, files } = e.target;
//         if (type === 'file') {
//             setNewEvent({ ...newEvent, [name]: files[0] });
//         } else {
//             setNewEvent({ ...newEvent, [name]: value });
//         }
//     };

//     const createEvent = async () => {
//         const { title, category, eventDate, venue, registrationLink, image } = newEvent;
        
//         if (!title || !category || !eventDate || !venue || !registrationLink) {
//             alert("Please fill in all mandatory fields: Title, Category, Date & Time, Venue, and Registration Link.");
//             return;
//         }

//         try {
//             let imageUrl = "";
//             if (image) {
//                 const storage = getStorage();
//                 const imageRef = ref(storage, `event_images/${image.name}`);
//                 const snapshot = await uploadBytes(imageRef, image);
//                 imageUrl = await getDownloadURL(snapshot.ref);
//             }

//             const docRef = await addDoc(collection(db, "events"), {
//                 ...newEvent,
//                 image: imageUrl,
//             });

//             alert("Event submitted successfully! Event ID: " + docRef.id);
//             setNewEvent({
//                 title: '', category: '', description: '', eventDate: '', venue: '',
//                 onlineLink: '', format: 'in-person', registrationLink: '', ticketPrice: '',
//                 paymentOptions: '', agenda: '', speakers: '', organizerDetails: '',
//                 contactInfo: '', specialInstructions: '', socialLinks: '', sponsors: '',
//                 image: null,
//             });
//         } catch (error) {
//             console.error("Error adding document: ", error);
//             alert("Error submitting event. Please try again.");
//         }
//     };

//     return (
//         <div className="event-organizer-container">
//             <nav className="navbar">
//                 <div className="navbar-left">
//                     <img src={ssnLogo} alt="SSN College Logo" className="ssn-logo" />
//                 </div>
//                 <div className="navbar-right">
//                     <a href="#" className="nav-link">Home</a>
//                     <a href="#" className="nav-link">About SSN</a>
//                     <a href="#" className="nav-link">Events</a>
//                     <input type="text" placeholder="Search..." className="search-bar" />
//                     <button className="logout-button">Logout</button>
//                 </div>
//             </nav>

//             {showBanner && (
//                 <div className="image-banner">
//                     <img src={ssnCampus} alt="SSN Campus" className="campus-image" />
//                     <div className="banner-text">EVENT ORGANIZER DASHBOARD</div>
//                 </div>
//             )}

//             <div className="dashboard-container">
//                 <div className="sidebar">
//                     <button className={activeTab === 'create' ? 'sidebar-btn active' : 'sidebar-btn'} onClick={() => setActiveTab('create')}>Create Event</button>
//                 </div>

//                 <div className="main-content">
//                     {activeTab === 'create' && (
//                         <div className="create-event">
//                             <h2>Create New Event</h2>
//                             <label>Event Title:</label>
//                             <input type="text" name="title" value={newEvent.title} onChange={handleInputChange} placeholder="Enter event title" required />
//                             <label>Category:</label>
//                             <select name="category" value={newEvent.category} onChange={handleInputChange} required>
//                                 <option value="">Select Category</option>
//                                 <option value="Workshop">Workshop</option>
//                                 <option value="Seminar">Seminar</option>
//                                 <option value="Conference">Conference</option>
//                                 <option value="Cultural">Cultural</option>
//                             </select>
//                             <label>Date & Time:</label>
//                             <input type="datetime-local" name="eventDate" value={newEvent.eventDate} onChange={handleInputChange} required />
//                             <label>Venue:</label>
//                             <input type="text" name="venue" value={newEvent.venue} onChange={handleInputChange} placeholder="Enter venue" required />
//                             <label>Registration Link:</label>
//                             <input type="text" name="registrationLink" value={newEvent.registrationLink} onChange={handleInputChange} placeholder="Enter registration link" required />
//                             <label>Upload Image:</label>
//                             <input type="file" name="image" onChange={handleInputChange} />
//                             <button className="create-button" onClick={createEvent}>Submit Event</button>
//                         </div>
//                     )}
//                 </div>
//             </div>
//         </div>
//     );
// };

// export default EventOrganizer;










// import React, { useState, useEffect } from 'react';
// import { db,storage } from "./firebase"; 
// import { collection, addDoc } from "firebase/firestore";
// import { getStorage, ref, uploadBytes, getDownloadURL } from "firebase/storage";
// import './EventOrganizer.css';
// import ssnLogo from './assets/ssnLogo.png';
// import ssnCampus from './assets/ssn_campus.jpeg';

// const EventOrganizer = () => {
//     const [activeTab, setActiveTab] = useState('create');
//     const [showBanner, setShowBanner] = useState(true);
//     const [newEvent, setNewEvent] = useState({
//         title: '',
//         category: '',
//         description: '',
//         eventDate: '',
//         venue: '',
//         onlineLink: '',
//         format: 'in-person',
//         registrationLink: '',
//         ticketPrice: '',
//         paymentOptions: '',
//         agenda: '',
//         speakers: '',
//         organizerDetails: '',
//         contactInfo: '',
//         specialInstructions: '',
//         socialLinks: '',
//         sponsors: '',
//         image: null,
//     });

//     useEffect(() => {
//         document.body.style.background = "#ffffff";

//         const handleScroll = () => {
//             setShowBanner(window.scrollY <= 100);
//         };
//         window.addEventListener('scroll', handleScroll);
//         return () => window.removeEventListener('scroll', handleScroll);
//     }, []);

//     const handleInputChange = (e) => {
//         const { name, value, type, files } = e.target;
//         if (type === 'file') {
//             setNewEvent({ ...newEvent, [name]: files[0] });
//         } else {
//             setNewEvent({ ...newEvent, [name]: value });
//         }
//     };

//     const createEvent = async () => {
//         const { title, category, eventDate, venue, registrationLink, image } = newEvent;
        
//         if (!title || !category || !eventDate || !venue || !registrationLink) {
//             alert("Please fill in all mandatory fields: Title, Category, Date & Time, Venue, and Registration Link.");
//             return;
//         }

//         try {
//             let imageUrl = "";
//             if (image) {
//                 // const storage = getStorage();
//                 const imageRef = ref(storage, `event_images/${image.name}`);
//                 const snapshot = await uploadBytes(imageRef, image);
//                 imageUrl = await getDownloadURL(snapshot.ref);
//             }

//             const docRef = await addDoc(collection(db, "events"), {
//                 ...newEvent,
//                 image: imageUrl,
//             });

//             alert("Event submitted successfully! Event ID: " + docRef.id);
//             setNewEvent({
//                 title: '', category: '', description: '', eventDate: '', venue: '',
//                 onlineLink: '', format: 'in-person', registrationLink: '', ticketPrice: '',
//                 paymentOptions: '', agenda: '', speakers: '', organizerDetails: '',
//                 contactInfo: '', specialInstructions: '', socialLinks: '', sponsors: '',
//                 image: null,
//             });
//         } catch (error) {
//             console.error("Error adding document: ", error);
//             alert("Error submitting event. Please try again.");
//         }
//     };

//     return (
//         <div className="event-organizer-container">
//             <nav className="navbar">
//                 <div className="navbar-left">
//                     <img src={ssnLogo} alt="SSN College Logo" className="ssn-logo" />
//                 </div>
//                 <div className="navbar-right">
//                     <a href="#" className="nav-link">Home</a>
//                     <a href="#" className="nav-link">About SSN</a>
//                     <a href="#" className="nav-link">Events</a>
//                     <input type="text" placeholder="Search..." className="search-bar" />
//                     <button className="logout-button">Logout</button>
//                 </div>
//             </nav>

//             {showBanner && (
//                 <div className="image-banner">
//                     <img src={ssnCampus} alt="SSN Campus" className="campus-image" />
//                     <div className="banner-text">EVENT ORGANIZER DASHBOARD</div>
//                 </div>
//             )}

//             <div className="dashboard-container">
//                 <div className="sidebar">
//                     <button className={activeTab === 'create' ? 'sidebar-btn active' : 'sidebar-btn'} onClick={() => setActiveTab('create')}>Create Event</button>
//                 </div>

//                 <div className="main-content">
//                     {activeTab === 'create' && (
//                         <div className="create-event">
//                             <h2>Create New Event</h2>
//                             <label>Event Title:</label>
//                             <input type="text" name="title" value={newEvent.title} onChange={handleInputChange} placeholder="Enter event title" required />
//                             <label>Category:</label>
//                             <select name="category" value={newEvent.category} onChange={handleInputChange} required>
//                                 <option value="">Select Category</option>
//                                 <option value="Workshop">Workshop</option>
//                                 <option value="Seminar">Seminar</option>
//                                 <option value="Conference">Conference</option>
//                                 <option value="Cultural">Cultural</option>
//                             </select>
//                             <label>Date & Time:</label>
//                             <input type="datetime-local" name="eventDate" value={newEvent.eventDate} onChange={handleInputChange} required />
//                             <label>Venue:</label>
//                             <input type="text" name="venue" value={newEvent.venue} onChange={handleInputChange} placeholder="Enter venue" required />
//                             <label>Registration Link:</label>
//                             <input type="text" name="registrationLink" value={newEvent.registrationLink} onChange={handleInputChange} placeholder="Enter registration link" required />
//                             <label>Upload Image:</label>
//                             <input type="file" name="image" onChange={handleInputChange} />
//                             <button className="create-button" onClick={createEvent}>Submit Event</button>
//                         </div>
//                     )}
//                 </div>
//             </div>
//         </div>
//     );
// };

// export default EventOrganizer;

// import React, { useState, useEffect } from 'react';
// import { db, storage } from "./firebase"; 
// import { collection, addDoc } from "firebase/firestore";
// import { ref, uploadBytes, getDownloadURL } from "firebase/storage"; // Removed redundant getStorage import
// import './EventOrganizer.css';
// import ssnLogo from './assets/ssnLogo.png';
// import ssnCampus from './assets/ssn_campus.jpeg';

// const EventOrganizer = () => {
//     const [activeTab, setActiveTab] = useState('create');
//     const [showBanner, setShowBanner] = useState(true);
//     const [newEvent, setNewEvent] = useState({
//         title: '',
//         category: '',
//         description: '',
//         eventDate: '',
//         venue: '',
//         onlineLink: '',
//         format: 'in-person',
//         registrationLink: '',
//         ticketPrice: '',
//         paymentOptions: '',
//         agenda: '',
//         speakers: '',
//         organizerDetails: '',
//         contactInfo: '',
//         specialInstructions: '',
//         socialLinks: '',
//         sponsors: '',
//         image: null,
//     });

//     useEffect(() => {
//         document.body.style.background = "#ffffff";

//         const handleScroll = () => {
//             setShowBanner(window.scrollY <= 100);
//         };
//         window.addEventListener('scroll', handleScroll);
//         return () => window.removeEventListener('scroll', handleScroll);
//     }, []);

//     const handleInputChange = (e) => {
//         const { name, value, type, files } = e.target;
//         if (type === 'file') {
//             setNewEvent({ ...newEvent, [name]: files[0] });
//         } else {
//             setNewEvent({ ...newEvent, [name]: value });
//         }
//     };

//     const createEvent = async () => {
//         const { title, category, eventDate, venue, registrationLink, image } = newEvent;
        
//         if (!title || !category || !eventDate || !venue || !registrationLink) {
//             alert("Please fill in all mandatory fields: Title, Category, Date & Time, Venue, and Registration Link.");
//             return;
//         }

//         try {
//             let imageUrl = "";
//             if (image) {
//                 const imageRef = ref(storage, `event_images/${image.name}`);
//                 const snapshot = await uploadBytes(imageRef, image);
//                 imageUrl = await getDownloadURL(snapshot.ref);
//             }

//             const docRef = await addDoc(collection(db, "events"), {
//                 ...newEvent,
//                 image: imageUrl,
//             });

//             alert("Event submitted successfully! Event ID: " + docRef.id);
//             setNewEvent({
//                 title: '', category: '', description: '', eventDate: '', venue: '',
//                 onlineLink: '', format: 'in-person', registrationLink: '', ticketPrice: '',
//                 paymentOptions: '', agenda: '', speakers: '', organizerDetails: '',
//                 contactInfo: '', specialInstructions: '', socialLinks: '', sponsors: '',
//                 image: null,
//             });
//         } catch (error) {
//             console.error("Error adding document: ", error);
//             alert("Error submitting event. Please try again.");
//         }
//     };

//     return (
//         <div className="event-organizer-container">
//             <nav className="navbar">
//                 <div className="navbar-left">
//                     <img src={ssnLogo} alt="SSN College Logo" className="ssn-logo" />
//                 </div>
//                 <div className="navbar-right">
//                     <a href="#" className="nav-link">Home</a>
//                     <a href="#" className="nav-link">About SSN</a>
//                     <a href="#" className="nav-link">Events</a>
//                     <input type="text" placeholder="Search..." className="search-bar" />
//                     <button className="logout-button">Logout</button>
//                 </div>
//             </nav>

//             {showBanner && (
//                 <div className="image-banner">
//                     <img src={ssnCampus} alt="SSN Campus" className="campus-image" />
//                     <div className="banner-text">EVENT ORGANIZER DASHBOARD</div>
//                 </div>
//             )}

//             <div className="dashboard-container">
//                 <div className="sidebar">
//                     <button className={activeTab === 'create' ? 'sidebar-btn active' : 'sidebar-btn'} onClick={() => setActiveTab('create')}>Create Event</button>
//                 </div>

//                 <div className="main-content">
//                     {activeTab === 'create' && (
//                         <div className="create-event">
//                             <h2>Create New Event</h2>
//                             <label>Event Title:</label>
//                             <input type="text" name="title" value={newEvent.title} onChange={handleInputChange} placeholder="Enter event title" required />
//                             <label>Category:</label>
//                             <select name="category" value={newEvent.category} onChange={handleInputChange} required>
//                                 <option value="">Select Category</option>
//                                 <option value="Workshop">Workshop</option>
//                                 <option value="Seminar">Seminar</option>
//                                 <option value="Conference">Conference</option>
//                                 <option value="Cultural">Cultural</option>
//                             </select>
//                             <label>Date & Time:</label>
//                             <input type="datetime-local" name="eventDate" value={newEvent.eventDate} onChange={handleInputChange} required />
//                             <label>Venue:</label>
//                             <input type="text" name="venue" value={newEvent.venue} onChange={handleInputChange} placeholder="Enter venue" required />
//                             <label>Registration Link:</label>
//                             <input type="text" name="registrationLink" value={newEvent.registrationLink} onChange={handleInputChange} placeholder="Enter registration link" required />
//                             <label>Upload Image:</label>
//                             <input type="file" name="image" onChange={handleInputChange} />
//                             <button className="create-button" onClick={createEvent}>Submit Event</button>
//                         </div>
//                     )}
//                 </div>
//             </div>
//         </div>
//     );
// };

// export default EventOrganizer;


//4/4/25  6:00
import React, { useState, useEffect } from 'react';
import { db, storage } from "./firebase"; 
import { collection, addDoc } from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import './EventOrganizer.css';
import ssnLogo from './assets/ssnLogo.png';
import ssnCampus from './assets/ssn_campus.jpeg';
import { useAuth } from "../contexts/AuthContext"; // 👈 Add this line
import { useNavigate } from 'react-router-dom'; // Optional, for redirect after logout


const EventOrganizer = () => {
    const { currentUser , logout} = useAuth(); // 👈 Access user
    const [activeTab, setActiveTab] = useState('create');
    const [showBanner, setShowBanner] = useState(true);
    const navigate = useNavigate(); // If you're using react-router
    const [newEvent, setNewEvent] = useState({
        title: '', category: '', description: '', eventDate: '', venue: '',
        onlineLink: '', format: 'in-person', registrationLink: '', ticketPrice: '',
        paymentOptions: '', agenda: '', speakers: '', organizerDetails: '',
        contactInfo: '', specialInstructions: '', socialLinks: '', sponsors: '',
        image: null,
    });

    useEffect(() => {
        document.body.style.background = "#ffffff";
        const handleScroll = () => setShowBanner(window.scrollY <= 100);
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    const handleLogout = async () => {
    try {
        await logout();
        navigate("/login"); // Or use window.location.href = "/login"
    } catch (error) {
        console.error("Logout failed:", error);
    }
    };

    const handleInputChange = (e) => {
        const { name, value, type, files } = e.target;
        if (type === 'file') {
            setNewEvent({ ...newEvent, [name]: files[0] });
        } else {
            setNewEvent({ ...newEvent, [name]: value });
        }
    };

    const createEvent = async () => {
        const { title, category, eventDate, venue, registrationLink, image } = newEvent;
        if (!title || !category || !eventDate || !venue || !registrationLink) {
            alert("Please fill in all mandatory fields.");
            return;
        }

        try {
            let imageUrl = "";
            if (image) {
                const imageRef = ref(storage, `event_images/${image.name}`);
                const snapshot = await uploadBytes(imageRef, image);
                imageUrl = await getDownloadURL(snapshot.ref);
            }

            const docRef = await addDoc(collection(db, "events"), {
                ...newEvent,
                image: imageUrl,
                createdBy: currentUser?.displayName || "unknown", // ✅ Store who created it
            });

            alert("Event submitted successfully! Event ID: " + docRef.id);
            setNewEvent({
                title: '', category: '', description: '', eventDate: '', venue: '',
                onlineLink: '', format: 'in-person', registrationLink: '', ticketPrice: '',
                paymentOptions: '', agenda: '', speakers: '', organizerDetails: '',
                contactInfo: '', specialInstructions: '', socialLinks: '', sponsors: '',
                image: null,
            });
        } catch (error) {
            console.error("Error adding document: ", error);
            alert("Error submitting event. Please try again.");
        }
    };

    return (
        <div className="event-organizer-container">
            <nav className="navbar">
                <div className="navbar-left">
                    <img src={ssnLogo} alt="SSN College Logo" className="ssn-logo" />
                </div>
                <div className="navbar-right">
                    <span className="user-info">Welcome, {currentUser?.email || "Guest"}</span> {/* 👈 SHOW USER */}
                    <a href="#" className="nav-link">Home</a>
                    <a href="#" className="nav-link">About SSN</a>
                    <a href="#" className="nav-link">Events</a>
                    <input type="text" placeholder="Search..." className="search-bar" />
                    <button className="logout-button" onClick={handleLogout}>Logout</button>
                </div>
            </nav>

            {showBanner && (
                <div className="image-banner">
                    <img src={ssnCampus} alt="SSN Campus" className="campus-image" />
                    <div className="banner-text">EVENT ORGANIZER DASHBOARD</div>
                </div>
            )}

            <div className="dashboard-container">
                <div className="sidebar">
                    <button className={activeTab === 'create' ? 'sidebar-btn active' : 'sidebar-btn'} onClick={() => setActiveTab('create')}>Create Event</button>
                </div>

                <div className="main-content">
                    {activeTab === 'create' && (
                        <div className="create-event">
                            <h2>Create New Event</h2>
                            <label>Event Title:</label>
                            <input type="text" name="title" value={newEvent.title} onChange={handleInputChange} placeholder="Enter event title" required />
                            <label>Category:</label>
                            <select name="category" value={newEvent.category} onChange={handleInputChange} required>
                                <option value="">Select Category</option>
                                <option value="Workshop">Workshop</option>
                                <option value="Seminar">Seminar</option>
                                <option value="Conference">Conference</option>
                                <option value="Cultural">Cultural</option>
                            </select>
                            <label>Date & Time:</label>
                            <input type="datetime-local" name="eventDate" value={newEvent.eventDate} onChange={handleInputChange} required />
                            <label>Venue:</label>
                            <input type="text" name="venue" value={newEvent.venue} onChange={handleInputChange} placeholder="Enter venue" required />
                            <label>Registration Link:</label>
                            <input type="text" name="registrationLink" value={newEvent.registrationLink} onChange={handleInputChange} placeholder="Enter registration link" required />
                            <label>Upload Image:</label>
                            <input type="file" name="image" onChange={handleInputChange} />
                            <button className="create-button" onClick={createEvent}>Submit Event</button>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default EventOrganizer;
