import bisect
from flask import Flask, jsonify, request
from flask_cors import CORS
import heapq
from collections import deque

from flask_cors import CORS
app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})  # Allow all origins

# Sample event data
events = {
    "upcoming": [
        {"id": 1, "title": "Tech Talk 2025", "date": "2025-03-10"},
        {"id": 2, "title": "Hackathon", "date": "2025-03-15"},
        {"id": 3, "title": "Web Dev Workshop", "date": "2025-03-12"},
        {"id": 4, "title": "AI Seminar", "date": "2025-03-18"},
        {"id": 5, "title": "Python Bootcamp", "date": "2025-03-20"}
    ],
    "pending": [
        {"id": 10, "title": "Workshop on AI", "date": "2025-03-05"},
        {"id": 11, "title": "Digital Marketing", "date": "2025-03-08"},
        {"id": 12, "title": "Blockchain Summit", "date": "2025-03-09"},
        {"id": 13, "title": "Cybersecurity Bootcamp", "date": "2025-03-07"}
    ],
    "approved": [
        {"id": 6, "title": "Cultural Fest", "date": "2025-02-28"},
        {"id": 7, "title": "Women in Tech", "date": "2025-02-25"},
        {"id": 8, "title": "Startup Expo", "date": "2025-03-01"},
        {"id": 9, "title": "Ethnic Day", "date": "2025-03-03"}
    ],
    "history": [
        {"id": 14, "title": "Alumni Meet", "date": "2025-01-20"},
        {"id": 15, "title": "Science Fair", "date": "2025-01-18"},
        {"id": 16, "title": "Tech Quiz", "date": "2025-01-22"},
        {"id": 17, "title": "Project Expo", "date": "2025-01-25"}
    ]
}

class BPlusTreeNode:
    def __init__(self, is_leaf=False):
        self.is_leaf = is_leaf
        self.keys = []
        self.values = []  # Stores event details
        self.children = []
        self.next = None  # Leaf node pointer for range queries

class BPlusTree:
    def __init__(self, order=4):  # Adjust order based on efficiency
        self.root = BPlusTreeNode(True)
        self.order = order

    def search(self, key, node=None):
        if node is None:
            node = self.root
        if node.is_leaf:
            return [event for k, event in zip(node.keys, node.values) if k == key]
        idx = bisect.bisect_left(node.keys, key)
        return self.search(key, node.children[idx])

    def insert(self, key, value):
        root = self.root
        new_child, new_key = self._insert_recursive(root, key, value)
        if new_child:
            new_root = BPlusTreeNode(False)
            new_root.keys.append(new_key)
            new_root.children.append(root)
            new_root.children.append(new_child)
            self.root = new_root

    def _insert_recursive(self, node, key, value):
        if node.is_leaf:
            idx = bisect.bisect_left(node.keys, key)
            node.keys.insert(idx, key)
            node.values.insert(idx, value)

            if len(node.keys) > self.order - 1:
                return self._split_leaf(node)

            return None, None

        idx = bisect.bisect_left(node.keys, key)
        new_child, new_key = self._insert_recursive(node.children[idx], key, value)
        if new_child:
            node.keys.insert(idx, new_key)
            node.children.insert(idx + 1, new_child)
            if len(node.keys) >= self.order:
                return self._split_internal(node)

        return None, None

    def _split_leaf(self, node):
        mid = len(node.keys) // 2
        new_leaf = BPlusTreeNode(True)
        new_leaf.keys = node.keys[mid:]
        new_leaf.values = node.values[mid:]
        node.keys = node.keys[:mid]
        node.values = node.values[:mid]
        new_leaf.next = node.next
        node.next = new_leaf
        return new_leaf, new_leaf.keys[0]

    def _split_internal(self, node):
        mid = len(node.keys) // 2
        mid_key = node.keys[mid]  # Store the middle key before modifying the list
        new_internal = BPlusTreeNode(False)
        new_internal.keys = node.keys[mid + 1:]  # Right half keys
        new_internal.children = node.children[mid + 1:]  # Right half children

        node.keys = node.keys[:mid]  # Left half keys
        node.children = node.children[:mid + 1]  # Left half children

        return new_internal, mid_key  # Return the stored middle key

    def inorder_traversal(self):
        node = self.root
        while not node.is_leaf:
            node = node.children[0]
        result = []
        while node:
            result.extend(zip(node.keys, node.values))
            node = node.next
        return result

    def delete(self, key):
        node = self.root
        while not node.is_leaf:
            idx = bisect.bisect_left(node.keys, key)
            node = node.children[idx]
        if key in node.keys:
            idx = node.keys.index(key)
            node.keys.pop(idx)
            node.values.pop(idx)

class EventGraph:
    def __init__(self):
        self.adj_list = {}

    def add_edge(self, u, v, weight=1):
        if u not in self.adj_list:
            self.adj_list[u] = []
        if v not in self.adj_list:
            self.adj_list[v] = []
        self.adj_list[u].append((v, weight))

    def bfs(self, start):
        visited, queue = set(), deque([start])
        order = []
        while queue:
            node = queue.popleft()
            if node not in visited:
                visited.add(node)
                order.append(node)
                for neighbor, _ in self.adj_list[node]:
                    if neighbor not in visited:
                        queue.append(neighbor)
        return order

    def dfs(self, start, visited=None):
        if visited is None:
            visited = set()
        visited.add(start)
        order = [start]
        for neighbor, _ in self.adj_list.get(start, []):
            if neighbor not in visited:
                order.extend(self.dfs(neighbor, visited))
        return order

    def dijkstra(self, start):
        heap = [(0, start)]
        distances = {node: float('inf') for node in self.adj_list}
        if start not in self.adj_list:
            return {}
        distances[start] = 0
        while heap:
            current_distance, current_node = heapq.heappop(heap)
            if current_distance > distances[current_node]:
                continue
            for neighbor, weight in self.adj_list[current_node]:
                distance = current_distance + weight
                if distance < distances[neighbor]:
                    distances[neighbor] = distance
                    heapq.heappush(heap, (distance, neighbor))
        return distances

@app.route('/')
def home():
    return jsonify({"message": "Welcome to the Event Management System API", "endpoints": ["/events", "/add_event", "/delete_event/<date>"]})

event_tree = BPlusTree(order=4)
event_graph = EventGraph()

@app.route('/events', methods=['GET'])
def get_events():
    print("Events Data:", events)  # Debugging
    return jsonify(events)
 # Return the full events dictionary


@app.route('/add_event', methods=['POST'])
def add_event():
    data = request.json
    if "date" not in data or "title" not in data:
        return jsonify({"error": "Missing required fields"}), 400
    if event_tree.search(data["date"]):
        return jsonify({"error": "Event with this date already exists"}), 409
    event_tree.insert(data["date"], data)
    return jsonify({"message": "Event added successfully"}), 201

@app.route('/delete_event/<date>', methods=['DELETE'])
def delete_event(date):
    events = event_tree.search(date)
    if not events:
        return jsonify({"error": "Event not found"}), 404
    event_tree.delete(date)
    return jsonify({"message": "Event deleted"}), 200

@app.route('/shortest_approval_path', methods=['GET'])
def get_approval_path():
    if "submission" not in event_graph.adj_list:
        return jsonify({"error": "No submission node found"}), 404
    return jsonify(event_graph.dijkstra("submission"))

# Populate B+ Tree with initial events
for category in events:
    for event in events[category]:
        event_tree.insert(event["date"], event)

if __name__ == '__main__':
    app.run(debug=True)
