import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Home from './components/Home';
import LoginForm from './components/LoginForm';
import EventOrganizer from './components/EventOrganizer';
import EventOrganizerSignIn from './components/EventOrganizerSignIn';
import Admin from './components/Admin';
import ProtectedRoute from './components/ProtectedRoute';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/home" element={<Home />} />
        <Route path="/login" element={<LoginForm />} />
        <Route path="/signin" element={<EventOrganizerSignIn />} />
        <Route
          path="/eventorganizer"
          element={<ProtectedRoute>
            <EventOrganizer />
          </ProtectedRoute>} />
        <Route
          path="/admin"
          element={<ProtectedRoute>
            <Admin />
          </ProtectedRoute>} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;